<?php
define('RAZORPAY_KEY', 'rzp_test_ABC123XYZ');      // Your Key ID
define('RAZORPAY_SECRET', 'your_secret_here');     // Your Secret
     // Replace with your Key Secret
?>

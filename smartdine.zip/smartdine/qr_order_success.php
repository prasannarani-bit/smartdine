<?php
include('includes/db.php');
session_start();

$table_no = $_GET['table_no'] ?? 0;
if(!$table_no || empty($_SESSION['table_cart'][$table_no])){
    echo "Cart empty"; exit;
}

$total=0;
foreach($_SESSION['table_cart'][$table_no] as $c) $total += $c['price']*$c['quantity'];

mysqli_query($conn,"INSERT INTO orders(user_id,NULL,table_no,total) VALUES(NULL,'$table_no','$total')");
$order_id = mysqli_insert_id($conn);

foreach($_SESSION['table_cart'][$table_no] as $id=>$c){
    mysqli_query($conn,"INSERT INTO order_items(order_id,menu_item_id,quantity) VALUES('$order_id','$id','{$c['quantity']}')");
}

unset($_SESSION['table_cart'][$table_no]);

echo "<div style='text-align:center;margin-top:100px;'>
<h2>🎉 Payment Successful!</h2>
<p>Order ID: <b>#$order_id</b></p>
<p>Table: <b>$table_no</b></p>
<a href='menu.php' class='btn btn-primary mt-3'>Back to Menu</a>
</div>";
?>

<?php
session_start();
include('includes/db.php');

$table_no = $_GET['table_no'] ?? 0; // Get table number from QR

if(!$table_no){ echo "Invalid Table"; exit; }

if(!isset($_SESSION['table_cart'])) $_SESSION['table_cart'] = [];

if(isset($_POST['add_to_cart'])){
    $item_id = $_POST['item_id'];
    $quantity = $_POST['quantity'];
    $item = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM menu_items WHERE id='$item_id'"));

    if(!isset($_SESSION['table_cart'][$table_no])) $_SESSION['table_cart'][$table_no] = [];

    if(isset($_SESSION['table_cart'][$table_no][$item_id])){
        $_SESSION['table_cart'][$table_no][$item_id]['quantity'] += $quantity;
    } else {
        $_SESSION['table_cart'][$table_no][$item_id] = [
            'name'=>$item['name'],
            'price'=>$item['price'],
            'quantity'=>$quantity
        ];
    }
    header("Location: qr_cart.php?table_no=$table_no");
    exit;
}

if(isset($_GET['remove'])){
    unset($_SESSION['table_cart'][$table_no][$_GET['remove']]);
    header("Location: qr_cart.php?table_no=$table_no");
    exit;
}

$total=0;
if(isset($_SESSION['table_cart'][$table_no])){
    foreach($_SESSION['table_cart'][$table_no] as $c) $total += $c['price']*$c['quantity'];
}
?>
<!DOCTYPE html>
<html>
<head>
<title>QR Cart | Table <?php echo $table_no;?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
<h3>Table <?php echo $table_no;?> Cart</h3>

<?php if(empty($_SESSION['table_cart'][$table_no])): ?>
<p>Cart empty. <a href="menu.php">Back to Menu</a></p>
<?php else: ?>
<table class="table table-bordered">
<thead><tr><th>Item</th><th>Price</th><th>Qty</th><th>Subtotal</th><th>Action</th></tr></thead>
<tbody>
<?php foreach($_SESSION['table_cart'][$table_no] as $id=>$c): ?>
<tr>
<td><?php echo $c['name'];?></td>
<td>₹<?php echo $c['price'];?></td>
<td><?php echo $c['quantity'];?></td>
<td>₹<?php echo $c['price']*$c['quantity'];?></td>
<td><a href="qr_cart.php?table_no=<?php echo $table_no;?>&remove=<?php echo $id;?>" class="btn btn-danger btn-sm">Remove</a></td>
</tr>
<?php endforeach; ?>
<tr><td colspan="3"><b>Total</b></td><td colspan="2"><b>₹<?php echo $total;?></b></td></tr>
</tbody>
</table>
<form method="POST" action="qr_checkout.php?table_no=<?php echo $table_no;?>">
<button class="btn btn-success w-100">Proceed to Payment</button>
</form>
<?php endif; ?>
</div>
</body>
</html>

<?php
include('includes/db.php');
include('includes/config.php');
session_start();

$table_no = $_GET['table_no'] ?? 0;
if(!$table_no || empty($_SESSION['table_cart'][$table_no])){
    echo "Cart empty"; exit;
}

$total=0;
foreach($_SESSION['table_cart'][$table_no] as $c) $total += $c['price']*$c['quantity'];
?>
<!DOCTYPE html>
<html>
<head>
<title>QR Checkout | Table <?php echo $table_no;?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5" style="max-width:500px;">
<h3>Table <?php echo $table_no;?> Checkout</h3>
<ul>
<?php foreach($_SESSION['table_cart'][$table_no] as $c): ?>
<li><?php echo $c['name'];?> x <?php echo $c['quantity'];?> = ₹<?php echo $c['price']*$c['quantity'];?></li>
<?php endforeach; ?>
</ul>
<p><b>Total: ₹<?php echo $total;?></b></p>

<form>
<script src="https://checkout.razorpay.com/v1/checkout.js"
data-key="<?php echo RAZORPAY_KEY;?>"
data-amount="<?php echo $total*100;?>"
data-currency="INR"
data-buttontext="Pay ₹<?php echo $total;?>"
data-name="SmartDine"
data-description="Table <?php echo $table_no;?> Order"
data-prefill.name="Customer"
data-prefill.email="customer@example.com"
data-theme.color="#F37254"
data-handler="function(response){ window.location='qr_order_success.php?table_no=<?php echo $table_no;?>'; }">
</script>
</form>
</div>
</body>
</html>
